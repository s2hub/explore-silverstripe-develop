<?php
$val .= '<div class="page__content">
    <h1 class="page__title">';

$val .= $scope->locally()->getOutputValue('Title', []);
$val .= '</h1>
    ';

$val .= $scope->locally()->getOutputValue('Content', []);
$val .= '
    ';

$val .= $scope->locally()->getOutputValue('ElementalArea', []);
$val .= '
    ';

$val .= $scope->locally()->getOutputValue('Form', []);
$val .= '
</div>
';

if ($scope->locally()->getOutputValue('PageLevel', [])==1&&$scope->locally()->hasValue('Children', [])) { 
$val .= '
    ';

$val .= \SilverStripe\TemplateEngine\SSTemplateEngine::execute_template([["type" => "Includes", 'LevelOneSidebar'], 'LevelOneSidebar'], $scope->getCurrentItem(), [], $scope, true);

$val .= '
';


}else if ($scope->locally()->getOutputValue('PageLevel', [])>1&&$scope->locally()->scopeToIntermediateValue('Menu', [$scope->locally()->getValueAsArgument('PageLevel', [])])->getOutputValue('count', [])>1) { 
$val .= '
    ';

$val .= \SilverStripe\TemplateEngine\SSTemplateEngine::execute_template([["type" => "Includes", 'Sidebar'], 'Sidebar'], $scope->getCurrentItem(), [], $scope, true);

$val .= '
';


}
$val .= '
';

