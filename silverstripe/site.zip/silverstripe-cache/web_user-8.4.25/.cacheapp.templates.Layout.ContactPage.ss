<?php
\SilverStripe\View\Requirements::css('app/client/css/contacts.css');
$val .= '
<div class="page__content">
    ';

$scope->locally()->scopeToIntermediateValue('Contact', []); $scope->pushScope();
$val .= '
        <h1 class="page__title">';

$val .= $scope->locally()->getOutputValue('Title', []);
$val .= '</h1>
        <dl class="contact">
            ';

if ($scope->locally()->hasValue('Company', [])) { 
$val .= '<dt>Company</dt><dd>';

$val .= $scope->locally()->getOutputValue('Company', []);
$val .= '</dd>';


}
$val .= '
            ';

if ($scope->locally()->hasValue('Category', [])) { 
$val .= '<dt>Category</dt><dd>';

$val .= $scope->locally()->scopeToIntermediateValue('Category', [])->getOutputValue('Title', []);
$val .= '</dd>';


}
$val .= '
            ';

if ($scope->locally()->hasValue('Email', [])) { 
$val .= '<dt>Email</dt><dd><a href="mailto:';

$val .= $scope->locally()->getOutputValue('Email', []);
$val .= '">';

$val .= $scope->locally()->getOutputValue('Email', []);
$val .= '</a></dd>';


}
$val .= '
            ';

if ($scope->locally()->hasValue('Phone', [])) { 
$val .= '<dt>Phone</dt><dd><a href="tel:';

$val .= $scope->locally()->getOutputValue('Phone', []);
$val .= '">';

$val .= $scope->locally()->getOutputValue('Phone', []);
$val .= '</a></dd>';


}
$val .= '
        </dl>
    ';


; $scope->popScope(); 
$val .= '
</div>
';

