<?php
$val .= '<footer class="footer">
    <div class="container container--footer">
        <nav aria-label="Footer">
            <ul class="footer-menu">
                <li class="footer-menu__item footer-menu__item--copyright">
                    &copy; ';

$val .= $scope->locally()->scopeToIntermediateValue('Now', [])->getOutputValue('Format', ['y']);
$val .= ' ';

$val .= $scope->locally()->scopeToIntermediateValue('SiteConfig', [])->getOutputValue('Title', []);
$val .= '
                </li>
                ';

$scope->locally()->scopeToIntermediateValue('Menu', [1]); $scope->pushScope(); while ($scope->next() !== false) {
$val .= '
                    <li class="footer-menu__item">
                        <a href="';

$val .= $scope->locally()->getOutputValue('Link', []);
$val .= '" class="footer-menu__link">';

$val .= $scope->locally()->getOutputValue('MenuTitle', []);
$val .= '</a>
                    </li>
                ';


}; $scope->popScope(); 
$val .= '
            </ul>
        </nav>
        <a href="https://www.silverstripe.org/" class="footer__logo" target="_blank" rel="noopener noreferrer" aria-label="Silverstripe CMS">
            <img src="';

$val .= $scope->locally()->getOutputValue('resourceURL', ['themes/startup-theme/images/logo--silverstripe-cms.svg']);
$val .= '" width="176" height="21" alt="">
        </a>
    </div>
</footer>
';

