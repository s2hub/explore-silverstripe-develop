<?php
$val .= 'Require all denied
RewriteRule .* - [F]
';

