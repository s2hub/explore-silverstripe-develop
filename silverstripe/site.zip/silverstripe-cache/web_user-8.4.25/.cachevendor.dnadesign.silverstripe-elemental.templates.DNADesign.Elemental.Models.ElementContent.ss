<?php
$val .= '<div class="content-element__content';

if ($scope->locally()->hasValue('Style', [])) { 
$val .= ' ';

$val .= $scope->locally()->getOutputValue('StyleVariant', []);

}
$val .= '">
	';

if ($scope->locally()->hasValue('ShowTitle', [])) { 
$val .= '
        <h2 class="content-element__title">';

$val .= $scope->locally()->getOutputValue('Title', []);
$val .= '</h2>
    ';


}
$val .= '
    ';

$val .= $scope->locally()->getOutputValue('HTML', []);
$val .= '
</div>
';

