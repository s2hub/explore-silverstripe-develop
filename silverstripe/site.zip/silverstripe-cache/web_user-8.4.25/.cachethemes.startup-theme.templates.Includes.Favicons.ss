<?php
$val .= '<link rel="apple-touch-icon" sizes="180x180" href="';

$val .= $scope->locally()->getOutputValue('themedResourceURL', ['favicons/apple-touch-icon.png']);
$val .= '">
<link rel="icon" type="image/png" sizes="32x32" href="';

$val .= $scope->locally()->getOutputValue('themedResourceURL', ['favicons/favicon-32x32.png']);
$val .= '">
<link rel="icon" type="image/png" sizes="16x16" href="';

$val .= $scope->locally()->getOutputValue('themedResourceURL', ['favicons/favicon-16x16.png']);
$val .= '">
<link rel="manifest" href="';

$val .= $scope->locally()->getOutputValue('themedResourceURL', ['favicons/site.webmanifest']);
$val .= '">
<link rel="mask-icon" href="';

$val .= $scope->locally()->getOutputValue('themedResourceURL', ['favicons/safari-pinned-tab.svg']);
$val .= '" color="#051e2d">
<link rel="shortcut icon" href="';

$val .= $scope->locally()->getOutputValue('themedResourceURL', ['favicons/favicon.ico']);
$val .= '">
<meta name="msapplication-TileColor" content="#051e2d">
<meta name="msapplication-config" content="';

$val .= $scope->locally()->getOutputValue('themedResourceURL', ['favicons/browserconfig.xml']);
$val .= '">
<meta name="theme-color" content="#ffffff">
';

