<?php
$val .= '<div class="element ';

$val .= $scope->locally()->scopeToIntermediateValue('SimpleClassName', [])->getOutputValue('LowerCase', []);
if ($scope->locally()->hasValue('StyleVariant', [])) { 
$val .= ' ';

$val .= $scope->locally()->getOutputValue('StyleVariant', []);

}
if ($scope->locally()->hasValue('ExtraClass', [])) { 
$val .= ' ';

$val .= $scope->locally()->getOutputValue('ExtraClass', []);

}
$val .= '" id="';

$val .= $scope->locally()->getOutputValue('Anchor', []);
$val .= '">
	';

$val .= $scope->locally()->getOutputValue('Element', []);
$val .= '
</div>
';

