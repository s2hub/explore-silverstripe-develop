<?php
$val .= '<header class="header">
    <a href="#main" class="button button--on-dark button--skip">Skip to main content</a>

    <div class="container container--header">
        <a href="';

$val .= $scope->locally()->getOutputValue('baseURL', []);
$val .= '" class="logo" aria-label="Home">
            <img src="';

$val .= $scope->locally()->getOutputValue('themedResourceURL', ['images/logo--white.svg']);
$val .= '" width="117" height="22" alt="">
        </a>

        ';


$val .= '
        <nav class="nav nav--desktop" aria-label="Main">
            <ul class="menu">
                ';

$scope->locally()->scopeToIntermediateValue('Menu', [1]); $scope->pushScope(); while ($scope->next() !== false) {
$val .= '
                    <li class="menu__item menu__item--';

$val .= $scope->locally()->getOutputValue('LinkingMode', []);
$val .= ' ';

if ($scope->locally()->hasValue('Children', [])) { 
$val .= ' menu__item--has-submenu';


}
$val .= '">
                        <div class="menu__item-container">
                            <a id="';

$val .= $scope->locally()->getOutputValue('URLSegment', []);
$val .= '-submenu-link" href="';

$val .= $scope->locally()->getOutputValue('Link', []);
$val .= '" class="menu__link menu__link--';

$val .= $scope->locally()->getOutputValue('LinkingMode', []);
$val .= '"';

if ($scope->locally()->hasValue('Children', [])) { 
$val .= ' aria-haspopup="true" aria-controls="';

$val .= $scope->locally()->getOutputValue('URLSegment', []);
$val .= '-submenu" aria-expanded="false"';


}
$val .= '>
                                ';

$val .= $scope->locally()->getOutputValue('MenuTitle', []);
$val .= '
                            </a>
                            ';

if ($scope->locally()->hasValue('Children', [])) { 
$val .= '
                                <button
                                    class="submenu-chevron"
                                    type="button"
                                    aria-label="Open ';

$val .= $scope->locally()->getOutputValue('MenuTitle', []);
$val .= ' submenu"
                                    aria-controls="';

$val .= $scope->locally()->getOutputValue('URLSegment', []);
$val .= '-submenu"
                                    aria-expanded="false"
                                >
                                    <svg width="11" height="8" viewBox="0 0 11 8" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                        <path d="M0 1.88973L1.29663 0.5L5.50183 5.08612L9.70337 0.5L11 1.88973L5.50183 7.86607L0 1.88973Z" fill="currentcolor" />
                                    </svg>
                                </button>
                            ';


}
$val .= '
                        </div>
                        ';

if ($scope->locally()->hasValue('Children', [])) { 
$val .= '
                            <div
                                id="';

$val .= $scope->locally()->getOutputValue('URLSegment', []);
$val .= '-submenu"
                                class="submenu-container"
                                aria-labelledby="';

$val .= $scope->locally()->getOutputValue('URLSegment', []);
$val .= '-submenu-link"
                                aria-hidden="true"
                            >
                                <ul class="submenu">
                                    ';

$scope->locally()->scopeToIntermediateValue('Children', []); $scope->pushScope(); while ($scope->next() !== false) {
$val .= '
                                        <li class="submenu__item">
                                            <a href="';

$val .= $scope->locally()->getOutputValue('Link', []);
$val .= '" class="submenu__link submenu__link--';

$val .= $scope->locally()->getOutputValue('LinkingMode', []);
$val .= '">';

$val .= $scope->locally()->getOutputValue('MenuTitle', []);
$val .= '</a>
                                        </li>
                                    ';


}; $scope->popScope(); 
$val .= '
                                </ul>
                            </div>
                        ';


}
$val .= '
                    </li>
                ';


}; $scope->popScope(); 
$val .= '
            </ul>
        </nav>

        ';


$val .= '
        <button class="hamburger" type="button" aria-label="Toggle menu" data-toggle-mobile-menu>
            <span class="hamburger__lines"></span>
        </button>

        ';


$val .= '
        <div class="modal__background" data-toggle-mobile-menu></div>

        ';


$val .= '
        <nav class="nav nav--mobile" aria-label="Main">
            <a href="';

$val .= $scope->locally()->getOutputValue('BaseHref', []);
$val .= '" class="logo logo--mobile">
                <img class="logo__image" src="';

$val .= $scope->locally()->getOutputValue('themedResourceURL', ['images/logo--black.svg']);
$val .= '" width="117" height="22" alt="';

$val .= $scope->locally()->scopeToIntermediateValue('SiteConfig', [])->getOutputValue('Title', []);
$val .= '">
            </a>
            <ul class="mobile-menu accordion">
                ';

$scope->locally()->scopeToIntermediateValue('Menu', [1]); $scope->pushScope(); while ($scope->next() !== false) {
$val .= '
                    <li class="mobile-menu__item';

if ($scope->locally()->hasValue('Children', [])) { 
$val .= ' mobile-menu__item--has-submenu accordion__item';


}
$val .= '">
                        <a href="';

$val .= $scope->locally()->getOutputValue('Link', []);
$val .= '" id="';

$val .= $scope->locally()->getOutputValue('URLSegment', []);
$val .= '-mobile-submenu-link" class="mobile-menu__link"
                        >';

$val .= $scope->locally()->getOutputValue('MenuTitle', []);
$val .= '</a>
                        ';

if ($scope->locally()->hasValue('Children', [])) { 
$val .= '
                            <button class="mobile-submenu-chevron accordion__toggle" type="button" aria-label="Open ';

$val .= $scope->locally()->getOutputValue('MenuTitle', []);
$val .= ' submenu" aria-expanded="false" aria-controls="';

$val .= $scope->locally()->getOutputValue('URLSegment', []);
$val .= '-mobile-submenu">
                                <svg width="11" height="8" viewBox="0 0 11 8" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" data-accordion-flip>
                                    <path d="M0 1.88973L1.29663 0.5L5.50183 5.08612L9.70337 0.5L11 1.88973L5.50183 7.86607L0 1.88973Z" fill="currentcolor"/>
                                </svg>
                            </button>
                            <div id="';

$val .= $scope->locally()->getOutputValue('URLSegment', []);
$val .= '-mobile-submenu" class="mobile-submenu-container accordion__container" aria-labelledby="';

$val .= $scope->locally()->getOutputValue('URLSegment', []);
$val .= '-mobile-submenu-link">
                                <ul class="mobile-submenu">
                                    ';

$scope->locally()->scopeToIntermediateValue('Children', []); $scope->pushScope(); while ($scope->next() !== false) {
$val .= '
                                        <li class="mobile-submenu__item">
                                            <a href="';

$val .= $scope->locally()->getOutputValue('Link', []);
$val .= '" title="';

$val .= $scope->locally()->getOutputValue('Title', []);
$val .= '" class="mobile-submenu__link">';

$val .= $scope->locally()->getOutputValue('MenuTitle', []);
$val .= '</a>
                                        </li>
                                    ';


}; $scope->popScope(); 
$val .= '
                                </ul>
                            </div>
                        ';


}
$val .= '
                    </li>
                ';


}; $scope->popScope(); 
$val .= '
            </ul>
        </nav>
    </div>
</header>
';

