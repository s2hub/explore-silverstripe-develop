<?php
if ($scope->locally()->hasValue('ElementControllers', [])) { 
$val .= '
    ';

$scope->locally()->scopeToIntermediateValue('ElementControllers', []); $scope->pushScope(); while ($scope->next() !== false) {
$val .= '
	   ';

$val .= $scope->locally()->getOutputValue('Me', []);
$val .= '
    ';


}; $scope->popScope(); 
$val .= '
';


}
$val .= '
';

