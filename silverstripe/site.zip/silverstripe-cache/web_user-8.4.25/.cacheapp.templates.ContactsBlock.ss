<?php
\SilverStripe\View\Requirements::css('app/client/css/contacts.css');
$val .= '
';

if ($scope->locally()->hasValue('ShowTitle', [])) { 
$val .= '
    <h2>';

$val .= $scope->locally()->getOutputValue('Title', []);
$val .= '</h2>
';


}
$val .= '
<ul class="contacts">
    ';

$scope->locally()->scopeToIntermediateValue('Contacts', []); $scope->pushScope(); while ($scope->next() !== false) {
$val .= '
        <li class="contacts__item">
            <a class="contacts__name" href="';

$val .= $scope->locally()->getOutputValue('Link', []);
$val .= '">';

$val .= $scope->locally()->getOutputValue('Title', []);
$val .= '</a>
            ';

if ($scope->locally()->hasValue('Company', [])) { 
$val .= '<span class="contacts__company">';

$val .= $scope->locally()->getOutputValue('Company', []);
$val .= '</span>';


}
$val .= '
            ';

if ($scope->locally()->hasValue('Email', [])) { 
$val .= '<a class="contacts__email" href="mailto:';

$val .= $scope->locally()->getOutputValue('Email', []);
$val .= '">';

$val .= $scope->locally()->getOutputValue('Email', []);
$val .= '</a>';


}
$val .= '
        </li>
    ';


}; $scope->popScope(); 
$val .= '
</ul>
';

