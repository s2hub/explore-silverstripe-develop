<?php
$val .= '<nav class="breadcrumbs" aria-label="Breadcrumbs">
    <ol class="breadcrumbs__list">
        <li class="breadcrumbs__list-item">
            <a href="';

$val .= $scope->locally()->getOutputValue('BaseURL', []);
$val .= '">';

$val .= _t('StartupTheme.BREADCRUMBS_HOME','Home');
$val .= '</a>
            <span class="breadcrumbs__list-delimiter" aria-hidden="true">/</span>
        </li>
        ';

$scope->locally()->scopeToIntermediateValue('Pages', []); $scope->pushScope(); while ($scope->next() !== false) {
$val .= '
            ';

if (!$scope->locally()->hasValue('IsLast', [])&&!$scope->locally()->hasValue('isHomePage', [])) { 
$val .= '
                <li class="breadcrumbs__list-item">
                    ';

if (!$scope->locally()->scopeToIntermediateValue('Up', [])->hasValue('Unlinked', [])) { 
$val .= '<a href="';

$val .= $scope->locally()->getOutputValue('Link', []);
$val .= '">';


}
$val .= $scope->locally()->scopeToIntermediateValue('MenuTitle', [])->getOutputValue('XML', []);
if (!$scope->locally()->scopeToIntermediateValue('Up', [])->hasValue('Unlinked', [])) { 
$val .= '</a>';


}
$val .= '
                    <span class="breadcrumbs__list-delimiter" aria-hidden="true">/</span>
                </li>
            ';


}
$val .= '
        ';


}; $scope->popScope(); 
$val .= '
    </ol>
</nav>
';

