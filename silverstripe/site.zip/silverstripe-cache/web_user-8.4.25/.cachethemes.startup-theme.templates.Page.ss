<?php
$val .= '<!doctype html>
<html lang="';

$val .= $scope->locally()->getOutputValue('ContentLocale', []);
$val .= '">
<head>
    ';

$isXhtml = preg_match('/<!DOCTYPE[^>]+xhtml/i', $val);
$val .= \SilverStripe\View\SSViewer::getBaseTag($isXhtml);
$val .= '
    ';


$val .= '
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    ';

$val .= $scope->locally()->getOutputValue('MetaTags', [false]);
$val .= '

    ';

$val .= \SilverStripe\TemplateEngine\SSTemplateEngine::execute_template([["type" => "Includes", 'Favicons'], 'Favicons'], $scope->getCurrentItem(), [], $scope, true);

$val .= '
    ';

\SilverStripe\View\Requirements::themedCSS('startup');
$val .= '

    <title>';

if ($scope->locally()->hasValue('MetaTitle', [])) { 
$val .= $scope->locally()->getOutputValue('MetaTitle', []);

}else { 
$val .= $scope->locally()->getOutputValue('Title', []);

}
$val .= ' | ';

$val .= $scope->locally()->scopeToIntermediateValue('SiteConfig', [])->getOutputValue('Title', []);
$val .= '</title>
</head>
<body ';

if ($scope->locally()->hasValue('i18nScriptDirection', [])) { 
$val .= 'dir="';

$val .= $scope->locally()->getOutputValue('i18nScriptDirection', []);
$val .= '"';


}
$val .= '>
    ';

$val .= \SilverStripe\TemplateEngine\SSTemplateEngine::execute_template([["type" => "Includes", 'Header'], 'Header'], $scope->getCurrentItem(), [], $scope, true);

$val .= '
    <main id="main" class="container container--page" tabindex="-1">
        ';

if (!$scope->locally()->hasValue('isHomePage', [])) { 
$val .= '
            ';

$val .= $scope->locally()->getOutputValue('Breadcrumbs', []);
$val .= '
        ';


}
$val .= '
        <div class="page">
            ';

$val .= $scope->locally()->getOutputValue('Layout', []);
$val .= '
        </div>
    </main>

    ';

$val .= \SilverStripe\TemplateEngine\SSTemplateEngine::execute_template([["type" => "Includes", 'Footer'], 'Footer'], $scope->getCurrentItem(), [], $scope, true);

$val .= '
    ';

if ($scope->locally()->hasValue('HasPerm', ['CMS_ACCESS'])) { 
$val .= $scope->locally()->getOutputValue('SilverStripeNavigator', []);

}
$val .= '
    <script type="module" src="';

$val .= $scope->locally()->getOutputValue('themedResourceURL', ['js/startup.js']);
$val .= '" defer></script>
</body>
</html>
';

